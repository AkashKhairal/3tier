using ERP_Project.Data;
using ERP_Project.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace ERP_Project.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly DbPracticeContext _dbPracticeContext;

        public HomeController(ILogger<HomeController> logger, DbPracticeContext dbPracticeContext)
        {
            _logger = logger;
            _dbPracticeContext = dbPracticeContext;
        }

        public IActionResult Index()
        {
            var Employee = _dbPracticeContext.Employees.ToList();

            return View(Employee);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
