﻿using System;
using System.Collections.Generic;

namespace ERP_Project.Models;

public partial class Entrymode
{
    public int Id { get; set; }

    public string? EntryModename { get; set; }

    public string? Crdr { get; set; }

    public int? Entrymodeno { get; set; }

    public virtual ICollection<CommonFeeCollection> CommonFeeCollections { get; set; } = new List<CommonFeeCollection>();

    public virtual ICollection<FinancialTran> FinancialTrans { get; set; } = new List<FinancialTran>();
}
