﻿using System;
using System.Collections.Generic;

namespace ERP_Project.Models;

public partial class Feecategory1
{
    public int Id { get; set; }

    public string? FeeCategory { get; set; }

    public int? BrId { get; set; }
}
