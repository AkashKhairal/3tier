﻿using System;
using System.Collections.Generic;

namespace ERP_Project.Models;

public partial class BioStat
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string? Sex { get; set; }

    public int? Age { get; set; }

    public int? Height { get; set; }

    public int? Weight { get; set; }
}
