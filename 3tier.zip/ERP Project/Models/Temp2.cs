﻿using System;
using System.Collections.Generic;

namespace ERP_Project.Models;

public partial class Temp2
{
    public string? Collectionhead { get; set; }

    public int? BrId { get; set; }
}
