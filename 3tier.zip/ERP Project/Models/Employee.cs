﻿using System;
using System.Collections.Generic;

namespace ERP_Project.Models;

public partial class Employee
{
    public int? EmpId { get; set; }

    public string? EmpName { get; set; }

    public string? Dept { get; set; }

    public int? Salary { get; set; }

    public string? City { get; set; }

    public int? JoinYear { get; set; }
}
