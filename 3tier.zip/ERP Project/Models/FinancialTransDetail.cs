﻿using System;
using System.Collections.Generic;

namespace ERP_Project.Models;

public partial class FinancialTransDetail
{
    public int Id { get; set; }

    public int? FinancialTranId { get; set; }

    public int? ModuleId { get; set; }

    public float? Amount { get; set; }

    public int? HeadId { get; set; }

    public string? Crdr { get; set; }

    public int? BrId { get; set; }

    public string? HeadName { get; set; }

    public virtual FinancialTran? FinancialTran { get; set; }
}
