﻿using System;
using System.Collections.Generic;

namespace ERP_Project.Models;

public partial class Employee1
{
    public string? Name { get; set; }

    public int? Salary { get; set; }
}
