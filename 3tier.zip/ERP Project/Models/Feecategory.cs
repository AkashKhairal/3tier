﻿using System;
using System.Collections.Generic;

namespace ERP_Project.Models;

public partial class Feecategory
{
    public int Id { get; set; }

    public string? FeeCategory1 { get; set; }

    public int? BrId { get; set; }

    public virtual Branch? Br { get; set; }

    public virtual ICollection<Feetype> Feetypes { get; set; } = new List<Feetype>();
}
