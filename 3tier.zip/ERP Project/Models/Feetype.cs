﻿using System;
using System.Collections.Generic;

namespace ERP_Project.Models;

public partial class Feetype
{
    public int Id { get; set; }

    public int? FeeCategory { get; set; }

    public string? FName { get; set; }

    public int? CollectionId { get; set; }

    public int? BrId { get; set; }

    public int? SeqId { get; set; }

    public string? FeeTypeLedger { get; set; }

    public int? FeeHeadtype { get; set; }

    public virtual Feecollectiontype? Collection { get; set; }

    public virtual ICollection<CommonFeeCollectionHeadwise> CommonFeeCollectionHeadwises { get; set; } = new List<CommonFeeCollectionHeadwise>();

    public virtual Feecategory? FeeCategoryNavigation { get; set; }
}
