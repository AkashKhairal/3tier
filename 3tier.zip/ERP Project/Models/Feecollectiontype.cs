﻿using System;
using System.Collections.Generic;

namespace ERP_Project.Models;

public partial class Feecollectiontype
{
    public int Id { get; set; }

    public string? Collectionhead { get; set; }

    public string? Collectiondesc { get; set; }

    public int? BrId { get; set; }

    public virtual Branch? Br { get; set; }

    public virtual ICollection<Feetype> Feetypes { get; set; } = new List<Feetype>();
}
