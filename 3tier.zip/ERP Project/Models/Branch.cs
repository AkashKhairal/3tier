﻿using System;
using System.Collections.Generic;

namespace ERP_Project.Models;

public partial class Branch
{
    public int Id { get; set; }

    public string? BranchName { get; set; }

    public virtual ICollection<Feecategory> Feecategories { get; set; } = new List<Feecategory>();

    public virtual ICollection<Feecollectiontype> Feecollectiontypes { get; set; } = new List<Feecollectiontype>();
}
