﻿using System;
using System.Collections.Generic;

namespace ERP_Project.Models;

public partial class Module
{
    public int ModuleId { get; set; }

    public string? ModuleName { get; set; }
}
