﻿using System;
using System.Collections.Generic;

namespace ERP_Project.Models;

public partial class FinancialTran
{
    public int Id { get; set; }

    public int? Moduleid { get; set; }

    public long? Transid { get; set; }

    public string? Admno { get; set; }

    public float? Amount { get; set; }

    public string? Crdr { get; set; }

    public DateTime? TranDate { get; set; }

    public string? AcadYear { get; set; }

    public int? Entrymode { get; set; }

    public long? Voucherno { get; set; }

    public int? Brid { get; set; }

    public string? TypeOfConcession { get; set; }

    public virtual Entrymode? EntrymodeNavigation { get; set; }

    public virtual ICollection<FinancialTransDetail> FinancialTransDetails { get; set; } = new List<FinancialTransDetail>();
}
