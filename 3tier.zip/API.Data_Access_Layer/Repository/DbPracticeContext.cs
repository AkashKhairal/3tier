﻿using System;
using System.Collections.Generic;
using ERP_API.Repository.Entities;
using Microsoft.EntityFrameworkCore;

namespace ERP_API.Repository;

public partial class DbPracticeContext : DbContext
{
    public DbPracticeContext()
    {
    }

    public DbPracticeContext(DbContextOptions<DbPracticeContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Address> Addresses { get; set; }

    public virtual DbSet<BioStat> BioStats { get; set; }

    public virtual DbSet<Branch> Branches { get; set; }

    public virtual DbSet<CommonFeeCollection> CommonFeeCollections { get; set; }

    public virtual DbSet<CommonFeeCollectionHeadwise> CommonFeeCollectionHeadwises { get; set; }

    public virtual DbSet<Country> Countries { get; set; }

    public virtual DbSet<Course> Courses { get; set; }

    public virtual DbSet<Customer> Customers { get; set; }

    public virtual DbSet<Employee> Employees { get; set; }

    public virtual DbSet<Employee1> Employees1 { get; set; }

    public virtual DbSet<Entrymode> Entrymodes { get; set; }

    public virtual DbSet<Feecategory> Feecategories { get; set; }

    public virtual DbSet<Feecategory1> Feecategory1s { get; set; }

    public virtual DbSet<Feecategory12> Feecategory12s { get; set; }

    public virtual DbSet<Feecollectiontype> Feecollectiontypes { get; set; }

    public virtual DbSet<Feetype> Feetypes { get; set; }

    public virtual DbSet<FinancialTran> FinancialTrans { get; set; }

    public virtual DbSet<FinancialTransDetail> FinancialTransDetails { get; set; }

    public virtual DbSet<Module> Modules { get; set; }

    public virtual DbSet<Payment> Payments { get; set; }

    public virtual DbSet<Student> Students { get; set; }

    public virtual DbSet<Temp2> Temp2s { get; set; }

    public virtual DbSet<Temp4fee> Temp4fees { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=AKASH\\SQLEXPRESS;Initial Catalog=DbPractice;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Address>(entity =>
        {
            entity.HasKey(e => e.AddressId).HasName("PK__Address__CAA247C838EB3E1B");

            entity.ToTable("Address");

            entity.Property(e => e.AddressId).HasColumnName("address_id");
            entity.Property(e => e.Address1)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Address");
            entity.Property(e => e.CityId).HasColumnName("city_id");
            entity.Property(e => e.PostalCode).HasColumnName("postal_code");

            entity.HasOne(d => d.City).WithMany(p => p.Addresses)
                .HasForeignKey(d => d.CityId)
                .HasConstraintName("FK_AddressCity");
        });

        modelBuilder.Entity<BioStat>(entity =>
        {
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Sex)
                .HasMaxLength(10)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Branch>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Branches__A1682FA578DA6AF1");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.BranchName)
                .HasMaxLength(255)
                .IsUnicode(false);
        });

        modelBuilder.Entity<CommonFeeCollection>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Common_f__3213E83F5B174C15");

            entity.ToTable("Common_fee_collection");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.AcadamicYear)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("acadamicYear");
            entity.Property(e => e.Admno)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("admno");
            entity.Property(e => e.Amount).HasColumnName("amount");
            entity.Property(e => e.BrId).HasColumnName("brId");
            entity.Property(e => e.DisplayReceiptNo)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("displayReceiptNo");
            entity.Property(e => e.FinancialYear)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("financialYear");
            entity.Property(e => e.Inactive)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("inactive");
            entity.Property(e => e.ModuleId).HasColumnName("moduleId");
            entity.Property(e => e.PaidDate)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Rollno)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("rollno");
            entity.Property(e => e.TransId).HasColumnName("transId");

            entity.HasOne(d => d.EntrymodeNavigation).WithMany(p => p.CommonFeeCollections)
                .HasForeignKey(d => d.Entrymode)
                .HasConstraintName("FK_Common_fee_collection_Entrymode");
        });

        modelBuilder.Entity<CommonFeeCollectionHeadwise>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Common_f__3213E83FDC5AA255");

            entity.ToTable("Common_fee_collection_headwise");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Amount).HasColumnName("amount");
            entity.Property(e => e.Brid).HasColumnName("brid");
            entity.Property(e => e.HeadId).HasColumnName("headId");
            entity.Property(e => e.HeadName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("headName");
            entity.Property(e => e.ModuleId).HasColumnName("moduleId");
            entity.Property(e => e.ReceiptId).HasColumnName("receiptId");

            entity.HasOne(d => d.Head).WithMany(p => p.CommonFeeCollectionHeadwises)
                .HasForeignKey(d => d.HeadId)
                .HasConstraintName("FK_Common_fee_collection_headwise_Feetypes");

            entity.HasOne(d => d.Receipt).WithMany(p => p.CommonFeeCollectionHeadwises)
                .HasForeignKey(d => d.ReceiptId)
                .HasConstraintName("FK_Common_fee_collection_headwise_Common_fee_collection");
        });

        modelBuilder.Entity<Country>(entity =>
        {
            entity.HasKey(e => e.CityId).HasName("PK__country__031491A82D3719ED");

            entity.ToTable("country");

            entity.Property(e => e.CityId).HasColumnName("city_id");
            entity.Property(e => e.City)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("city");
            entity.Property(e => e.Country1)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("country");
        });

        modelBuilder.Entity<Course>(entity =>
        {
            entity.HasKey(e => e.CourseId).HasName("PK__Courses__8F1EF7AE02EC8705");

            entity.Property(e => e.CourseId)
                .ValueGeneratedNever()
                .HasColumnName("course_id");
            entity.Property(e => e.CourseName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("course_name");
            entity.Property(e => e.InstructorName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("instructor_name");
            entity.Property(e => e.StudentId).HasColumnName("student_id");

            entity.HasOne(d => d.Student).WithMany(p => p.Courses)
                .HasForeignKey(d => d.StudentId)
                .HasConstraintName("FK__Courses__student__7CD98669");
        });

        modelBuilder.Entity<Customer>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Customer__3213E83F68D526FE");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Address)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.AddressId).HasColumnName("address_id");
            entity.Property(e => e.FirstName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.LastName)
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.HasOne(d => d.AddressNavigation).WithMany(p => p.Customers)
                .HasForeignKey(d => d.AddressId)
                .HasConstraintName("FK_CustomerAddress");
        });

        modelBuilder.Entity<Employee>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Employee");

            entity.Property(e => e.City)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("city");
            entity.Property(e => e.Dept)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("dept");
            entity.Property(e => e.EmpId).HasColumnName("empID");
            entity.Property(e => e.EmpName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("empName");
            entity.Property(e => e.JoinYear).HasColumnName("joinYear");
            entity.Property(e => e.Salary).HasColumnName("salary");
        });

        modelBuilder.Entity<Employee1>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Employees");

            entity.Property(e => e.Name)
                .HasMaxLength(1)
                .IsUnicode(false)
                .IsFixedLength();
        });

        modelBuilder.Entity<Entrymode>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Entrymod__3213E83F9E5955B7");

            entity.ToTable("Entrymode");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Crdr)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("crdr");
            entity.Property(e => e.EntryModename)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Entry_modename");
            entity.Property(e => e.Entrymodeno).HasColumnName("entrymodeno");
        });

        modelBuilder.Entity<Feecategory>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Feecateg__3213E83FA59E1073");

            entity.ToTable("Feecategory");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.BrId).HasColumnName("br_id");
            entity.Property(e => e.FeeCategory1)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("fee_category");

            entity.HasOne(d => d.Br).WithMany(p => p.Feecategories)
                .HasForeignKey(d => d.BrId)
                .HasConstraintName("FK_Feecategory_Branches");
        });

        modelBuilder.Entity<Feecategory1>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Feecateg__3213E83FF1C42BA1");

            entity.ToTable("Feecategory1");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.BrId).HasColumnName("br_id");
            entity.Property(e => e.FeeCategory)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("fee_category");
        });

        modelBuilder.Entity<Feecategory12>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Feecategory12");

            entity.Property(e => e.BrId).HasColumnName("br_id");
            entity.Property(e => e.FeeCategory)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("fee_category");
            entity.Property(e => e.Id)
                .ValueGeneratedOnAdd()
                .HasColumnName("id");
        });

        modelBuilder.Entity<Feecollectiontype>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Feecolle__3213E83F9C0E57DA");

            entity.ToTable("Feecollectiontype");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.BrId).HasColumnName("br_id");
            entity.Property(e => e.Collectiondesc)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("collectiondesc");
            entity.Property(e => e.Collectionhead)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("collectionhead");

            entity.HasOne(d => d.Br).WithMany(p => p.Feecollectiontypes)
                .HasForeignKey(d => d.BrId)
                .HasConstraintName("FK_Feecollectiontype_Branches");
        });

        modelBuilder.Entity<Feetype>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Feetypes__3214EC0761E84932");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.BrId).HasColumnName("br_id");
            entity.Property(e => e.CollectionId).HasColumnName("Collection_id");
            entity.Property(e => e.FName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("f_name");
            entity.Property(e => e.FeeCategory).HasColumnName("fee_category");
            entity.Property(e => e.FeeHeadtype).HasColumnName("Fee_headtype");
            entity.Property(e => e.FeeTypeLedger)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Fee_type_ledger");
            entity.Property(e => e.SeqId).HasColumnName("Seq_id");

            entity.HasOne(d => d.Collection).WithMany(p => p.Feetypes)
                .HasForeignKey(d => d.CollectionId)
                .HasConstraintName("FK_Feetypes_Feecollectiontype");

            entity.HasOne(d => d.FeeCategoryNavigation).WithMany(p => p.Feetypes)
                .HasForeignKey(d => d.FeeCategory)
                .HasConstraintName("FK_Feetypes_Feecategory");
        });

        modelBuilder.Entity<FinancialTran>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Financia__3214EC072D504286");

            entity.ToTable("Financial_trans");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.AcadYear)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("acadYear");
            entity.Property(e => e.Admno)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("admno");
            entity.Property(e => e.Amount).HasColumnName("amount");
            entity.Property(e => e.Brid).HasColumnName("brid");
            entity.Property(e => e.Crdr)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("crdr");
            entity.Property(e => e.Moduleid).HasColumnName("moduleid");
            entity.Property(e => e.TranDate)
                .HasColumnType("datetime")
                .HasColumnName("tranDate");
            entity.Property(e => e.Transid).HasColumnName("transid");
            entity.Property(e => e.TypeOfConcession)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("Type_of_concession");
            entity.Property(e => e.Voucherno).HasColumnName("voucherno");

            entity.HasOne(d => d.EntrymodeNavigation).WithMany(p => p.FinancialTrans)
                .HasForeignKey(d => d.Entrymode)
                .HasConstraintName("FK_Financial_trans_Entrymode");
        });

        modelBuilder.Entity<FinancialTransDetail>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Financia__3213E83F2395EA45");

            entity.ToTable("Financial_trans_details");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Amount).HasColumnName("amount");
            entity.Property(e => e.BrId).HasColumnName("br_id");
            entity.Property(e => e.Crdr)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("crdr");
            entity.Property(e => e.FinancialTranId).HasColumnName("financialTranId");
            entity.Property(e => e.HeadId).HasColumnName("headId");
            entity.Property(e => e.HeadName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("head_name");
            entity.Property(e => e.ModuleId).HasColumnName("moduleId");

            entity.HasOne(d => d.FinancialTran).WithMany(p => p.FinancialTransDetails)
                .HasForeignKey(d => d.FinancialTranId)
                .HasConstraintName("FK_Financial_trans_details_Financial_trans");
        });

        modelBuilder.Entity<Module>(entity =>
        {
            entity.HasKey(e => e.ModuleId).HasName("PK__Module__2B7477877AE9BF16");

            entity.ToTable("Module");

            entity.Property(e => e.ModuleId)
                .ValueGeneratedNever()
                .HasColumnName("ModuleID");
            entity.Property(e => e.ModuleName)
                .HasMaxLength(255)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Payment>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Payment");

            entity.Property(e => e.CustomersId).HasColumnName("customers_id");
            entity.Property(e => e.Mode)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("mode");
            entity.Property(e => e.PaymentDate)
                .HasColumnType("datetime")
                .HasColumnName("Payment_Date");

            entity.HasOne(d => d.Customers).WithMany()
                .HasForeignKey(d => d.CustomersId)
                .HasConstraintName("FK__Payment__custome__5BE2A6F2");
        });

        modelBuilder.Entity<Student>(entity =>
        {
            entity.HasKey(e => e.StudentId).HasName("PK__Students__2A33069A49218BBE");

            entity.Property(e => e.StudentId)
                .ValueGeneratedNever()
                .HasColumnName("student_id");
            entity.Property(e => e.DateOfBirth).HasColumnName("date_of_birth");
            entity.Property(e => e.FirstName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("first_name");
            entity.Property(e => e.LastName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("last_name");
        });

        modelBuilder.Entity<Temp2>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("temp2");

            entity.Property(e => e.BrId).HasColumnName("br_id");
            entity.Property(e => e.Collectionhead)
                .HasMaxLength(200)
                .HasColumnName("collectionhead");
        });

        modelBuilder.Entity<Temp4fee>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("temp4fee");

            entity.Property(e => e.FeeCategory)
                .HasMaxLength(200)
                .HasColumnName("fee_category");
            entity.Property(e => e.Id)
                .ValueGeneratedOnAdd()
                .HasColumnName("id");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
