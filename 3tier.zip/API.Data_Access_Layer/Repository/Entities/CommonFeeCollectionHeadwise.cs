﻿using System;
using System.Collections.Generic;

namespace ERP_API.Repository.Entities;

public partial class CommonFeeCollectionHeadwise
{
    public int Id { get; set; }

    public int? ModuleId { get; set; }

    public int? ReceiptId { get; set; }

    public int? HeadId { get; set; }

    public string? HeadName { get; set; }

    public int? Brid { get; set; }

    public double? Amount { get; set; }

    public virtual Feetype? Head { get; set; }

    public virtual CommonFeeCollection? Receipt { get; set; }
}
