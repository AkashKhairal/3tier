﻿using System;
using System.Collections.Generic;

namespace ERP_API.Repository.Entities;

public partial class Temp4fee
{
    public int Id { get; set; }

    public string? FeeCategory { get; set; }
}
