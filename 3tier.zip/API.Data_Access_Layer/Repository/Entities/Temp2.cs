﻿using System;
using System.Collections.Generic;

namespace ERP_API.Repository.Entities;

public partial class Temp2
{
    public string? Collectionhead { get; set; }

    public int? BrId { get; set; }
}
