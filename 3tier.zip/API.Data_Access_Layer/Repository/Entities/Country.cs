﻿using System;
using System.Collections.Generic;

namespace ERP_API.Repository.Entities;

public partial class Country
{
    public int CityId { get; set; }

    public string? City { get; set; }

    public string? Country1 { get; set; }

    public virtual ICollection<Address> Addresses { get; set; } = new List<Address>();
}
