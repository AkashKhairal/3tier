﻿using System;
using System.Collections.Generic;

namespace ERP_API.Repository.Entities;

public partial class Module
{
    public int ModuleId { get; set; }

    public string? ModuleName { get; set; }
}
