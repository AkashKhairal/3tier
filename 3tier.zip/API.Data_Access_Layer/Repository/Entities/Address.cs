﻿using System;
using System.Collections.Generic;

namespace ERP_API.Repository.Entities;

public partial class Address
{
    public int AddressId { get; set; }

    public string? Address1 { get; set; }

    public int? CityId { get; set; }

    public int? PostalCode { get; set; }

    public long? Phone { get; set; }

    public virtual Country? City { get; set; }

    public virtual ICollection<Customer> Customers { get; set; } = new List<Customer>();
}
