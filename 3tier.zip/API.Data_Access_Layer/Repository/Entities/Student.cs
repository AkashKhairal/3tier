﻿using System;
using System.Collections.Generic;

namespace ERP_API.Repository.Entities;

public partial class Student
{
    public int StudentId { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public DateOnly? DateOfBirth { get; set; }

    public virtual ICollection<Course> Courses { get; set; } = new List<Course>();
}
