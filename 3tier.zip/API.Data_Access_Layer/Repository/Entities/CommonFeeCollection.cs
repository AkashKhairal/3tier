﻿using System;
using System.Collections.Generic;

namespace ERP_API.Repository.Entities;

public partial class CommonFeeCollection
{
    public int Id { get; set; }

    public int? ModuleId { get; set; }

    public long? TransId { get; set; }

    public string? Admno { get; set; }

    public string? Rollno { get; set; }

    public float? Amount { get; set; }

    public int? BrId { get; set; }

    public string? AcadamicYear { get; set; }

    public string? FinancialYear { get; set; }

    public string? DisplayReceiptNo { get; set; }

    public int? Entrymode { get; set; }

    public string? PaidDate { get; set; }

    public string? Inactive { get; set; }

    public virtual ICollection<CommonFeeCollectionHeadwise> CommonFeeCollectionHeadwises { get; set; } = new List<CommonFeeCollectionHeadwise>();

    public virtual Entrymode? EntrymodeNavigation { get; set; }
}
