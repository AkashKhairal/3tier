﻿using ERP_API.Repository;
using ERP_API.Repository.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API.Data_Access_Layer
{
    public class EmployeeDAL
    {
        public EmployeeDAL() 
        {
        }


        public async Task<List<Employee>> GetAllEmployee()
        {
            var db = new DbPracticeContext();
            return db.Employees.ToList();
        }
    }
}
