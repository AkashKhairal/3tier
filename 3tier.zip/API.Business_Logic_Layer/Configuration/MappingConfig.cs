﻿using AutoMapper;
using ERP_API.Repository.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API.Business_Logic_Layer.Configuration
{
    public class MappingConfig : Profile
    {
        public MappingConfig()
        {
            CreateMap<EmployeeModel, Employee>().ReverseMap();
        }
    }
}
