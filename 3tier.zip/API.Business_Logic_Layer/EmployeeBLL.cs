﻿using API.Data_Access_Layer;
using AutoMapper;
using ERP_API.Repository.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API.Business_Logic_Layer
{
    public class EmployeeBLL
    {
        private EmployeeDAL _employeeDAL;
        private IMapper _mapper;

        public EmployeeBLL(IMapper mapper)
        {
            _employeeDAL = new EmployeeDAL();
            _mapper = mapper;
        }


        public async Task<List<EmployeeModel>> GetAllEmployees()
        {
            var employees = await _employeeDAL.GetAllEmployee();
            return _mapper.Map<List<EmployeeModel>>(employees);
        }
    }
}
